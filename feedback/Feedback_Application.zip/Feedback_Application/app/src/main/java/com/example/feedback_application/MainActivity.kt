package com.example.feedback_application

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.feedback_application.ui.AdminScreen
import com.example.feedback_application.ui.FeedbackViewModel
import com.example.feedback_application.ui.RatingScreen
import com.example.feedback_application.ui.theme.Feedback_ApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: FeedbackViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Feedback_ApplicationTheme {
                val navController = rememberNavController()
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NavHost(navController = navController, startDestination = "rating") {
                        composable("rating") {
                            RatingScreen(
                                viewModel = viewModel,
                                onAdminClick = { navController.navigate("admin") }
                            )
                        }
                        composable("admin") {
                            AdminScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
