package com.example.feedback_application.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SentimentDissatisfied
import androidx.compose.material.icons.filled.SentimentNeutral
import androidx.compose.material.icons.filled.SentimentSatisfied
import androidx.compose.material.icons.filled.SentimentVeryDissatisfied
import androidx.compose.material.icons.filled.SentimentVerySatisfied
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.feedback_application.data.Feedback
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AdminScreen(
    viewModel: FeedbackViewModel,
    onBack: () -> Unit
) {
    val allFeedback by viewModel.allFeedback.collectAsState()
    val context = LocalContext.current
    var showDeleteDialog by remember { mutableStateOf(false) }

    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { output ->
                output.write(viewModel.getExportJson().toByteArray())
            }
        }
    }

    AdminContent(
        allFeedback = allFeedback,
        onBack = onBack,
        onExport = {
            viewModel.exportToFile()?.let { uri ->
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Export Feedback"))
            }
        },
        onSaveToDevice = {
            saveLauncher.launch("feedback_${System.currentTimeMillis()}.json")
        },
        onClearRequest = { showDeleteDialog = true }
    )

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Clear All Data") },
            text = { Text("Are you sure you want to delete all feedback? This action cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearFeedback()
                        showDeleteDialog = false
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminContent(
    allFeedback: List<Feedback>,
    onBack: () -> Unit,
    onExport: () -> Unit,
    onSaveToDevice: () -> Unit,
    onClearRequest: () -> Unit
) {
    val configuration = LocalConfiguration.current
    val isLandscape =
        configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Feedback Analysis") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onSaveToDevice) { //Save json to device
                        Icon(Icons.Default.Save, contentDescription = "Save to Device")
                    }
                    IconButton(onClick = onExport) { //Export/share file via sharing options
                        Icon(Icons.Default.Share, contentDescription = "Export JSON")
                    }
                    IconButton(onClick = onClearRequest) { //delete/clear data
                        Icon(Icons.Default.Delete, contentDescription = "Clear All")
                    }
                }
            )
        }
    ) { padding ->
        if (allFeedback.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding), contentAlignment = Alignment.Center
            ) {
                Text("No feedback gathered yet.")
            }
        } else {
            if (isLandscape) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                    ) {
                        FeedbackSummary(allFeedback)
                        Spacer(modifier = Modifier.height(16.dp))
                        RatingChart(allFeedback)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Recent Feedback", style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            items(allFeedback) { feedback ->
                                FeedbackItem(feedback)
                            }
                        }
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(16.dp)
                ) {
                    FeedbackSummary(allFeedback)
                    Spacer(modifier = Modifier.height(24.dp))
                    RatingChart(allFeedback)
                    Spacer(modifier = Modifier.height(24.dp))
                    Text("Recent Feedback", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(allFeedback) { feedback ->
                            FeedbackItem(feedback)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FeedbackSummary(feedbackList: List<Feedback>) {
    val avg = if (feedbackList.isEmpty()) 0.0 else feedbackList.map { it.rating }.average()
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "Total Responses: ${feedbackList.size}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Average Rating: ${"%.2f".format(avg)} / 5.0",
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Composable
fun RatingChart(feedbackList: List<Feedback>) {
    val counts = feedbackList.groupBy { it.rating }.mapValues { it.value.size }
    val maxCount = (counts.values.maxOrNull() ?: 1).toFloat()

    val ratingData = listOf(
        5 to Icons.Default.SentimentVerySatisfied,
        4 to Icons.Default.SentimentSatisfied,
        3 to Icons.Default.SentimentNeutral,
        2 to Icons.Default.SentimentDissatisfied,
        1 to Icons.Default.SentimentVeryDissatisfied
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            .padding(16.dp)
    ) {
        Text(
            "Rating Distribution",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(16.dp))

        ratingData.forEach { (rating, icon) ->
            val count = counts[rating] ?: 0
            val fraction = count / maxCount

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                //icon
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                //rating
                Text(
                    text = "$rating",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(12.dp))
                //Horizontal Bar
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(12.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fraction)
                            .fillMaxHeight()
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                        MaterialTheme.colorScheme.primary
                                    )
                                )
                            )
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                //count
                Text(
                    text = count.toString(),
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.width(24.dp),
                    textAlign = TextAlign.End
                )
            }
        }
    }
}

@Composable
fun FeedbackItem(feedback: Feedback) {
    val date =
        SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(feedback.timestamp))
    ListItem(
        headlineContent = { Text("${feedback.rating} Stars", fontWeight = FontWeight.Medium) },
        supportingContent = { Text(date) },
        leadingContent = {
            val color = when (feedback.rating) {
                1 -> Color(0xFFE57373)
                2 -> Color(0xFFFFB74D)
                3 -> Color(0xFFFFF176)
                4 -> Color(0xFFAED581)
                else -> Color(0xFF81C784)
            }
            Surface(
                modifier = Modifier.size(12.dp),
                shape = RoundedCornerShape(2.dp),
                color = color
            ) {}
        }
    )
}