package com.example.feedback_application.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FeedbackDao {
    @Insert
    suspend fun insertFeedback(feedback: Feedback)

    @Query("SELECT * FROM feedback ORDER BY timestamp DESC")
    fun getAllFeedback(): Flow<List<Feedback>>

    @Query("SELECT * FROM feedback")
    suspend fun getAllFeedbackList(): List<Feedback>

    @Query("DELETE FROM feedback")
    suspend fun deleteAllFeedback()
}
