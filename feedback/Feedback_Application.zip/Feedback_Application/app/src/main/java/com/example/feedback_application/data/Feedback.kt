package com.example.feedback_application.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "feedback")
data class Feedback(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val rating: Int,
    val timestamp: Long = System.currentTimeMillis()
)
