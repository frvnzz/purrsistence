package com.example.feedback_application.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun RatingScreen(
    viewModel: FeedbackViewModel,
    onAdminClick: () -> Unit
) {
    val showConfirmation by viewModel.showConfirmation.collectAsState()
    var showPinDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        RatingContent(
            showConfirmation = showConfirmation,
            onRatingSelected = { viewModel.submitFeedback(it) }
        )

        // Admin Button in Corner
        IconButton(
            onClick = { showPinDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp)
                .size(24.dp),
            colors = IconButtonDefaults.iconButtonColors(
                contentColor = MaterialTheme.colorScheme.onBackground.copy(
                    alpha = 0.1f
                )
            )
        ) {
            Icon(Icons.Default.Settings, contentDescription = null)
        }
    }

    if (showPinDialog) {
        PinEntryDialog(
            onDismiss = { showPinDialog = false },
            onPinCorrect = {
                showPinDialog = false
                onAdminClick()
            }
        )
    }
}

@Composable
fun PinEntryDialog(
    onDismiss: () -> Unit,
    onPinCorrect: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Admin Access") },
        text = {
            Column {
                Text("Enter Passcode")
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = pin,
                    onValueChange = {
                        if (it.length <= 4 && it.all { char -> char.isDigit() }) {
                            pin = it
                            isError = false
                        }
                    },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = isError,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (isError) {
                    Text(
                        "Incorrect Passcode",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (pin == "1234") {
                    onPinCorrect()
                } else {
                    isError = true
                    pin = ""
                }
            }) {
                Text("Confirm")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun RatingContent(
    showConfirmation: Boolean,
    onRatingSelected: (Int) -> Unit
) {
    val smileys = listOf(
        Icons.Default.SentimentVeryDissatisfied to Color(0xFFE57373), // Red
        Icons.Default.SentimentDissatisfied to Color(0xFFFFB74D),     // Orange
        Icons.Default.SentimentNeutral to Color(0xFFFFF176),          // Yellow
        Icons.Default.SentimentSatisfied to Color(0xFFAED581),        // Light Green
        Icons.Default.SentimentVerySatisfied to Color(0xFF81C784)     // Green
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (!showConfirmation) {
            Text(
                text = "How would you rate your experience?",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 48.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                smileys.forEachIndexed { index, pair ->
                    val rating = index + 1
                    Icon(
                        imageVector = pair.first,
                        contentDescription = "$rating stars",
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .sizeIn(64.dp)
                            .clickable { onRatingSelected(rating) },
                        tint = pair.second
                    )
                }
            }
        } else {
            Text(
                text = "Thank you for your feedback!",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(32.dp))
            LinearProgressIndicator(modifier = Modifier.width(200.dp))
        }
    }
}