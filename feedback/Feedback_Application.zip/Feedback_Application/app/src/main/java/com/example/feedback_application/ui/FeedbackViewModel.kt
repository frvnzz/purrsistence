package com.example.feedback_application.ui

import android.app.Application
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.feedback_application.data.AppDatabase
import com.example.feedback_application.data.Feedback
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream

class FeedbackViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).feedbackDao()

    val allFeedback: StateFlow<List<Feedback>> = dao.getAllFeedback()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _showConfirmation = MutableStateFlow(false)
    val showConfirmation: StateFlow<Boolean> = _showConfirmation.asStateFlow()

    fun submitFeedback(rating: Int) {
        viewModelScope.launch {
            dao.insertFeedback(Feedback(rating = rating))
            _showConfirmation.value = true
            delay(3000)
            _showConfirmation.value = false
        }
    }

    fun exportToFile(): Uri? {
        return try {
            val json = Json.encodeToString(allFeedback.value)
            val file = File(getApplication<Application>().cacheDir, "feedback_export.json")
            FileOutputStream(file).use { 
                it.write(json.toByteArray()) 
            }
            FileProvider.getUriForFile(
                getApplication(),
                "${getApplication<Application>().packageName}.fileprovider",
                file
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun getExportJson(): String {
        return Json.encodeToString(allFeedback.value)
    }

    fun clearFeedback() {
        viewModelScope.launch {
            dao.deleteAllFeedback()
        }
    }
}
